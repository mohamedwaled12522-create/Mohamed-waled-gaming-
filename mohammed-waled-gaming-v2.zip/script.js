const input=document.getElementById("search");
const cards=document.querySelectorAll(".card");
input.addEventListener("input",()=>{const q=input.value.trim().toLowerCase();cards.forEach(c=>{c.style.display=c.dataset.name.toLowerCase().includes(q)?"":"none"})});
function coming(name){alert("🎮 لعبة "+name+" ستكون متاحة قريبًا!");}